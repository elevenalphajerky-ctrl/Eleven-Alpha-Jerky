
import React from "react";
import { motion } from "framer-motion";
import { Flame, Shield, Star, ShoppingBag, Package, ChevronRight } from "lucide-react";

const flavors = [
  { name: "Lucy's Cajun Campfire", profile: "Cajun heat, smoky depth, bold finish.", badge: "Cajun Smoke" },
  { name: "Slap the Smoke", profile: "Savory BBQ smoke with a punch of flavor.", badge: "BBQ Smoke" },
  { name: "Rub the Applewood", profile: "Applewood smoke, savory seasoning, balanced bite.", badge: "Applewood" },
  { name: "Cajun Hick", profile: "Cajun seasoning with a hickory-smoked backbone.", badge: "Hickory Cajun" }
];

const bundles = [
  { title: "Mission Pack", offer: "Buy 4, Get 1 Free", description: "Pick any five 2 oz packs and only pay for four.", price: "$40" },
  { title: "Sampler Pack", offer: "Four Flavor Trial", description: "Try the full lineup and find your favorite.", price: "$38" },
  { title: "Family Pack", offer: "Built for Sharing", description: "Larger bundle option for repeat customers and events.", price: "Custom" }
];

function Button({ children, variant = "solid", className = "", ...props }) {
  const base = "inline-flex items-center justify-center rounded-2xl px-6 py-3 font-bold transition";
  const styles = variant === "outline"
    ? "border border-zinc-700 text-zinc-100 hover:bg-zinc-900"
    : "bg-amber-500 text-zinc-950 hover:bg-amber-400";
  return <button className={`${base} ${styles} ${className}`} {...props}>{children}</button>;
}

function Card({ children }) {
  return <div className="rounded-3xl border border-zinc-800 bg-zinc-900/80 text-zinc-100 shadow-xl">{children}</div>;
}

export default function App() {
  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      <header className="sticky top-0 z-50 border-b border-zinc-800 bg-zinc-950/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
          <div>
            <p className="text-lg font-black tracking-wide">ELEVEN ALPHA</p>
            <p className="text-xs uppercase tracking-[0.35em] text-amber-500">Jerky</p>
          </div>
          <nav className="hidden gap-6 text-sm text-zinc-300 md:flex">
            <a href="#flavors" className="hover:text-amber-400">Flavors</a>
            <a href="#bundles" className="hover:text-amber-400">Bundles</a>
            <a href="#story" className="hover:text-amber-400">Story</a>
            <a href="#order" className="hover:text-amber-400">Order</a>
          </nav>
          <a href="#order"><Button>Order Now</Button></a>
        </div>
      </header>

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(245,158,11,0.18),transparent_35%),radial-gradient(circle_at_bottom_right,rgba(220,38,38,0.12),transparent_35%)]" />
        <div className="relative mx-auto grid max-w-6xl gap-10 px-5 py-20 md:grid-cols-2 md:py-28">
          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.55 }} className="flex flex-col justify-center">
            <div className="mb-5 inline-flex w-fit items-center gap-2 rounded-full border border-amber-500/40 bg-amber-500/10 px-4 py-2 text-sm text-amber-300">
              <Shield size={16} /> Veteran-Owned Premium Jerky
            </div>
            <h1 className="text-5xl font-black leading-tight tracking-tight md:text-7xl">Built with discipline. Packed with flavor.</h1>
            <p className="mt-6 max-w-xl text-lg leading-8 text-zinc-300">
              Small-batch jerky crafted for bold flavor, consistent quality, and the kind of snack that disappears fast.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <a href="#bundles"><Button className="px-7 py-4 text-base">Shop Bundles <ChevronRight className="ml-2" size={18} /></Button></a>
              <a href="#flavors"><Button variant="outline" className="px-7 py-4 text-base">View Flavors</Button></a>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.65, delay: 0.1 }} className="rounded-[2rem] border border-zinc-800 bg-zinc-900/70 p-6 shadow-2xl">
            <div className="rounded-[1.5rem] border border-zinc-800 bg-zinc-950 p-8 text-center">
              <div className="mx-auto mb-6 flex h-28 w-28 items-center justify-center rounded-full border border-amber-500/40 bg-amber-500/10">
                <Flame className="text-amber-400" size={54} />
              </div>
              <p className="text-4xl font-black">ELEVEN ALPHA</p>
              <p className="mt-2 text-sm uppercase tracking-[0.4em] text-amber-500">Jerky</p>
              <div className="mt-8 rounded-2xl bg-zinc-900 p-5">
                <p className="text-sm text-zinc-400">Current offer</p>
                <p className="mt-1 text-2xl font-black text-amber-400">Buy 4, Get 1 Free</p>
                <p className="mt-2 text-sm text-zinc-400">Build your own 5-pack Mission Pack.</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <section id="flavors" className="mx-auto max-w-6xl px-5 py-16">
        <div className="mb-10 flex items-end justify-between gap-4">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.35em] text-amber-500">Flavor Lineup</p>
            <h2 className="mt-3 text-4xl font-black">Choose your smoke.</h2>
          </div>
          <p className="hidden max-w-md text-right text-zinc-400 md:block">Four core flavors built around Cajun heat, BBQ smoke, applewood, and hickory.</p>
        </div>
        <div className="grid gap-5 md:grid-cols-4">
          {flavors.map((flavor) => (
            <Card key={flavor.name}>
              <div className="p-6">
                <div className="mb-5 inline-flex rounded-full bg-amber-500/10 px-3 py-1 text-xs font-bold uppercase tracking-wide text-amber-400">{flavor.badge}</div>
                <h3 className="text-xl font-black">{flavor.name}</h3>
                <p className="mt-3 text-sm leading-6 text-zinc-400">{flavor.profile}</p>
              </div>
            </Card>
          ))}
        </div>
      </section>

      <section id="bundles" className="bg-zinc-900/50 py-16">
        <div className="mx-auto max-w-6xl px-5">
          <p className="text-sm font-bold uppercase tracking-[0.35em] text-amber-500">Bundles</p>
          <h2 className="mt-3 text-4xl font-black">Deals that move product.</h2>
          <div className="mt-10 grid gap-5 md:grid-cols-3">
            {bundles.map((bundle) => (
              <Card key={bundle.title}>
                <div className="p-7">
                  <Package className="mb-5 text-amber-400" size={32} />
                  <h3 className="text-2xl font-black">{bundle.title}</h3>
                  <p className="mt-2 font-bold text-amber-400">{bundle.offer}</p>
                  <p className="mt-4 text-sm leading-6 text-zinc-400">{bundle.description}</p>
                  <div className="mt-6 flex items-center justify-between">
                    <span className="text-3xl font-black">{bundle.price}</span>
                    <a href="#order"><Button>Select</Button></a>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section id="story" className="mx-auto grid max-w-6xl gap-8 px-5 py-16 md:grid-cols-2">
        <div>
          <p className="text-sm font-bold uppercase tracking-[0.35em] text-amber-500">The Story</p>
          <h2 className="mt-3 text-4xl font-black">Veteran-owned. Process-driven. Flavor-first.</h2>
        </div>
        <div className="space-y-5 text-zinc-300">
          <p>Eleven Alpha Jerky was created to bring disciplined production thinking to a premium small-batch jerky brand. Every batch is built around consistency, quality, and repeatable flavor.</p>
          <p>The goal is simple: make jerky that tastes bold, feels premium, and earns repeat customers through quality — not gimmicks.</p>
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="rounded-2xl border border-zinc-800 p-4"><Star className="mb-2 text-amber-400" size={22} /><p className="font-bold">Premium Flavor</p></div>
            <div className="rounded-2xl border border-zinc-800 p-4"><Shield className="mb-2 text-amber-400" size={22} /><p className="font-bold">Veteran-Owned</p></div>
            <div className="rounded-2xl border border-zinc-800 p-4"><ShoppingBag className="mb-2 text-amber-400" size={22} /><p className="font-bold">Small Batch</p></div>
          </div>
        </div>
      </section>

      <section id="order" className="mx-auto max-w-6xl px-5 pb-20">
        <div className="rounded-[2rem] border border-amber-500/30 bg-amber-500/10 p-8 text-center md:p-12">
          <h2 className="text-4xl font-black">Ready to order?</h2>
          <p className="mx-auto mt-4 max-w-2xl text-zinc-300">
            Message Eleven Alpha Jerky to build a custom bundle, check current availability, or reserve your next batch.
          </p>
          <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
            <a href="mailto:tommyvanhouten4@gmail.com?subject=Eleven%20Alpha%20Jerky%20Order"><Button className="px-8 py-4 text-base">Message to Order</Button></a>
            <Button variant="outline" className="px-8 py-4 text-base">Follow on Facebook</Button>
          </div>
        </div>
      </section>

      <footer className="border-t border-zinc-800 px-5 py-8 text-center text-sm text-zinc-500">
        <p>© 2026 Eleven Alpha Jerky. Veteran-owned premium jerky.</p>
      </footer>
    </div>
  );
}
